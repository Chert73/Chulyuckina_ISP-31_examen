﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace uchet_telef_peregovorov
{
    /// <summary>
    /// Логика взаимодействия для Tarifi.xaml
    /// </summary>
    public partial class Tarifi : Window
    {
        public Tarifi()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1 uchet_telefonnih_peregovorovDataSet1 = ((uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1)(this.FindResource("uchet_telefonnih_peregovorovDataSet1")));
            // Загрузить данные в таблицу Тарифная_сетка. Можно изменить этот код как требуется.
            uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1TableAdapters.Тарифная_сеткаTableAdapter uchet_telefonnih_peregovorovDataSet1Тарифная_сеткаTableAdapter = new uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1TableAdapters.Тарифная_сеткаTableAdapter();
            uchet_telefonnih_peregovorovDataSet1Тарифная_сеткаTableAdapter.Fill(uchet_telefonnih_peregovorovDataSet1.Тарифная_сетка);
            System.Windows.Data.CollectionViewSource тарифная_сеткаViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("тарифная_сеткаViewSource")));
            тарифная_сеткаViewSource.View.MoveCurrentToFirst();
        }
    }
}
