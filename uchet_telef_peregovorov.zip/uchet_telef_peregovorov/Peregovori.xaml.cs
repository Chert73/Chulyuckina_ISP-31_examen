﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace uchet_telef_peregovorov
{
    /// <summary>
    /// Логика взаимодействия для Peregovori.xaml
    /// </summary>
    public partial class Peregovori : Window
    {
        public Peregovori()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Rasschet ras = new Rasschet();
            ras.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1 uchet_telefonnih_peregovorovDataSet1 = ((uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1)(this.FindResource("uchet_telefonnih_peregovorovDataSet1")));
            // Загрузить данные в таблицу Переговоры. Можно изменить этот код как требуется.
            uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1TableAdapters.ПереговорыTableAdapter uchet_telefonnih_peregovorovDataSet1ПереговорыTableAdapter = new uchet_telef_peregovorov.uchet_telefonnih_peregovorovDataSet1TableAdapters.ПереговорыTableAdapter();
            uchet_telefonnih_peregovorovDataSet1ПереговорыTableAdapter.Fill(uchet_telefonnih_peregovorovDataSet1.Переговоры);
            System.Windows.Data.CollectionViewSource переговорыViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("переговорыViewSource")));
            переговорыViewSource.View.MoveCurrentToFirst();
        }
    }
}
